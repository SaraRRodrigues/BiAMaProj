--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.12
-- Dumped by pg_dump version 9.5.12

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."Share" DROP CONSTRAINT "Share_forum_type_fkey";
ALTER TABLE ONLY public."Question" DROP CONSTRAINT "Question_forum_type_fkey";
ALTER TABLE ONLY public."Library_User" DROP CONSTRAINT "Library_User_user_id_fkey";
ALTER TABLE ONLY public."Library_User" DROP CONSTRAINT "Library_User_library_id_fkey";
ALTER TABLE ONLY public."Library_Material" DROP CONSTRAINT "Library_Material_material_id_fkey";
ALTER TABLE ONLY public."Library_Material" DROP CONSTRAINT "Library_Material_library_id_fkey";
ALTER TABLE ONLY public."Forum" DROP CONSTRAINT "Forum_library_id_fkey";
ALTER TABLE ONLY public."Favorite" DROP CONSTRAINT "Favorite_user_id_fkey";
ALTER TABLE ONLY public."Favorite" DROP CONSTRAINT "Favorite_material_id_fkey";
ALTER TABLE ONLY public."Curiosity" DROP CONSTRAINT "Curiosity_forum_type_fkey";
ALTER TABLE ONLY public."Answer" DROP CONSTRAINT "Answer_idQuestion_fkey";
ALTER TABLE ONLY public."Material" DROP CONSTRAINT material_pkey;
ALTER TABLE ONLY public."Library" DROP CONSTRAINT id;
ALTER TABLE ONLY public."User" DROP CONSTRAINT "User_username_key";
ALTER TABLE ONLY public."User" DROP CONSTRAINT "User_pkey1";
ALTER TABLE ONLY public."Share" DROP CONSTRAINT "Share_pkey";
ALTER TABLE ONLY public."Question" DROP CONSTRAINT "Question_pkey";
ALTER TABLE ONLY public."Notification" DROP CONSTRAINT "Notification_pkey";
ALTER TABLE ONLY public."Material" DROP CONSTRAINT "Material_code_key";
ALTER TABLE ONLY public."Library_User" DROP CONSTRAINT "Library_User_pkey";
ALTER TABLE ONLY public."Library_Material" DROP CONSTRAINT "Library_Material_pkey";
ALTER TABLE ONLY public."Forum" DROP CONSTRAINT "Forum_pkey";
ALTER TABLE ONLY public."Favorite" DROP CONSTRAINT "Favorite_pkey";
ALTER TABLE ONLY public."Curiosity" DROP CONSTRAINT "Curiosity_pkey";
ALTER TABLE ONLY public."Answer" DROP CONSTRAINT "Answer_pkey";
DROP TABLE public."User";
DROP SEQUENCE public.sequence_user;
DROP TABLE public."Share";
DROP TABLE public."Question";
DROP SEQUENCE public.sequence_start_0;
DROP TABLE public."Notification";
DROP SEQUENCE public.sequence_notification;
DROP TABLE public."Material";
DROP TABLE public."Library_User";
DROP TABLE public."Library_Material";
DROP TABLE public."Library";
DROP TABLE public."Forum";
DROP TABLE public."Favorite";
DROP TABLE public."Curiosity";
DROP TABLE public."Answer";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Answer; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Answer" (
    id_answer integer NOT NULL,
    id_question integer NOT NULL,
    text_answer text,
    "likesAnswer" integer
);


ALTER TABLE public."Answer" OWNER TO "BiAMa";

--
-- Name: Curiosity; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Curiosity" (
    forum_type text NOT NULL,
    title text,
    image text NOT NULL,
    "descriptionCuriosity" text
);


ALTER TABLE public."Curiosity" OWNER TO "BiAMa";

--
-- Name: Favorite; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Favorite" (
    id_favorite integer NOT NULL,
    user_id integer NOT NULL,
    material_id integer,
    question_id integer
);


ALTER TABLE public."Favorite" OWNER TO "BiAMa";

--
-- Name: Forum; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Forum" (
    type_forum text NOT NULL,
    library_id integer NOT NULL
);


ALTER TABLE public."Forum" OWNER TO "BiAMa";

--
-- Name: Library; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Library" (
    id_library integer NOT NULL,
    location text,
    description text,
    "locationDescription" text
);


ALTER TABLE public."Library" OWNER TO "BiAMa";

--
-- Name: Library_Material; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Library_Material" (
    library_id integer NOT NULL,
    material_id integer NOT NULL
);


ALTER TABLE public."Library_Material" OWNER TO "BiAMa";

--
-- Name: Library_User; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Library_User" (
    library_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public."Library_User" OWNER TO "BiAMa";

--
-- Name: Material; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Material" (
    id integer NOT NULL,
    type text,
    color text,
    code text,
    name text,
    category text,
    description text
);


ALTER TABLE public."Material" OWNER TO "BiAMa";

--
-- Name: sequence_notification; Type: SEQUENCE; Schema: public; Owner: BiAMa
--

CREATE SEQUENCE public.sequence_notification
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 999999
    CACHE 1;


ALTER TABLE public.sequence_notification OWNER TO "BiAMa";

--
-- Name: Notification; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Notification" (
    id_notification bigint DEFAULT nextval('public.sequence_notification'::regclass) NOT NULL,
    text_notification text,
    date_notification text,
    insert text
);


ALTER TABLE public."Notification" OWNER TO "BiAMa";

--
-- Name: sequence_start_0; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sequence_start_0
    START WITH 0
    INCREMENT BY 1
    MINVALUE 0
    MAXVALUE 999999
    CACHE 1;


ALTER TABLE public.sequence_start_0 OWNER TO postgres;

--
-- Name: Question; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Question" (
    id_question bigint DEFAULT nextval('public.sequence_start_0'::regclass) NOT NULL,
    text_question text,
    "likesQuestion" integer,
    forum_type text
);


ALTER TABLE public."Question" OWNER TO postgres;

--
-- Name: Share; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."Share" (
    forum_type text NOT NULL,
    title text,
    image text NOT NULL,
    "descriptionShare" text
);


ALTER TABLE public."Share" OWNER TO "BiAMa";

--
-- Name: sequence_user; Type: SEQUENCE; Schema: public; Owner: BiAMa
--

CREATE SEQUENCE public.sequence_user
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    MAXVALUE 9999999
    CACHE 1;


ALTER TABLE public.sequence_user OWNER TO "BiAMa";

--
-- Name: User; Type: TABLE; Schema: public; Owner: BiAMa
--

CREATE TABLE public."User" (
    id bigint DEFAULT nextval('public.sequence_user'::regclass) NOT NULL,
    name text,
    email text,
    birthdate text,
    image text,
    username text,
    password text
);


ALTER TABLE public."User" OWNER TO "BiAMa";

--
-- Data for Name: Answer; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Answer" (id_answer, id_question, text_answer, "likesAnswer") FROM stdin;
\.
COPY public."Answer" (id_answer, id_question, text_answer, "likesAnswer") FROM '$$PATH$$/2204.dat';

--
-- Data for Name: Curiosity; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Curiosity" (forum_type, title, image, "descriptionCuriosity") FROM stdin;
\.
COPY public."Curiosity" (forum_type, title, image, "descriptionCuriosity") FROM '$$PATH$$/2201.dat';

--
-- Data for Name: Favorite; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Favorite" (id_favorite, user_id, material_id, question_id) FROM stdin;
\.
COPY public."Favorite" (id_favorite, user_id, material_id, question_id) FROM '$$PATH$$/2205.dat';

--
-- Data for Name: Forum; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Forum" (type_forum, library_id) FROM stdin;
\.
COPY public."Forum" (type_forum, library_id) FROM '$$PATH$$/2196.dat';

--
-- Data for Name: Library; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Library" (id_library, location, description, "locationDescription") FROM stdin;
\.
COPY public."Library" (id_library, location, description, "locationDescription") FROM '$$PATH$$/2197.dat';

--
-- Data for Name: Library_Material; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Library_Material" (library_id, material_id) FROM stdin;
\.
COPY public."Library_Material" (library_id, material_id) FROM '$$PATH$$/2200.dat';

--
-- Data for Name: Library_User; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Library_User" (library_id, user_id) FROM stdin;
\.
COPY public."Library_User" (library_id, user_id) FROM '$$PATH$$/2199.dat';

--
-- Data for Name: Material; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Material" (id, type, color, code, name, category, description) FROM stdin;
\.
COPY public."Material" (id, type, color, code, name, category, description) FROM '$$PATH$$/2195.dat';

--
-- Data for Name: Notification; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Notification" (id_notification, text_notification, date_notification, insert) FROM stdin;
\.
COPY public."Notification" (id_notification, text_notification, date_notification, insert) FROM '$$PATH$$/2207.dat';

--
-- Data for Name: Question; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Question" (id_question, text_question, "likesQuestion", forum_type) FROM stdin;
\.
COPY public."Question" (id_question, text_question, "likesQuestion", forum_type) FROM '$$PATH$$/2203.dat';

--
-- Data for Name: Share; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."Share" (forum_type, title, image, "descriptionShare") FROM stdin;
\.
COPY public."Share" (forum_type, title, image, "descriptionShare") FROM '$$PATH$$/2202.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: BiAMa
--

COPY public."User" (id, name, email, birthdate, image, username, password) FROM stdin;
\.
COPY public."User" (id, name, email, birthdate, image, username, password) FROM '$$PATH$$/2198.dat';

--
-- Name: sequence_notification; Type: SEQUENCE SET; Schema: public; Owner: BiAMa
--

SELECT pg_catalog.setval('public.sequence_notification', 3, true);


--
-- Name: sequence_start_0; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sequence_start_0', 7, true);


--
-- Name: sequence_user; Type: SEQUENCE SET; Schema: public; Owner: BiAMa
--

SELECT pg_catalog.setval('public.sequence_user', 1, false);


--
-- Name: Answer_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_pkey" PRIMARY KEY (id_answer, id_question);


--
-- Name: Curiosity_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Curiosity"
    ADD CONSTRAINT "Curiosity_pkey" PRIMARY KEY (image);


--
-- Name: Favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_pkey" PRIMARY KEY (id_favorite, user_id);


--
-- Name: Forum_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Forum"
    ADD CONSTRAINT "Forum_pkey" PRIMARY KEY (type_forum);


--
-- Name: Library_Material_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_Material"
    ADD CONSTRAINT "Library_Material_pkey" PRIMARY KEY (library_id, material_id);


--
-- Name: Library_User_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_User"
    ADD CONSTRAINT "Library_User_pkey" PRIMARY KEY (library_id, user_id);


--
-- Name: Material_code_key; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT "Material_code_key" UNIQUE (code);


--
-- Name: Notification_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Notification"
    ADD CONSTRAINT "Notification_pkey" PRIMARY KEY (id_notification);


--
-- Name: Question_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_pkey" PRIMARY KEY (id_question);


--
-- Name: Share_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Share"
    ADD CONSTRAINT "Share_pkey" PRIMARY KEY (image);


--
-- Name: User_pkey1; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey1" PRIMARY KEY (id);


--
-- Name: User_username_key; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_username_key" UNIQUE (username);


--
-- Name: id; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library"
    ADD CONSTRAINT id PRIMARY KEY (id_library);


--
-- Name: material_pkey; Type: CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Material"
    ADD CONSTRAINT material_pkey PRIMARY KEY (id);


--
-- Name: Answer_idQuestion_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Answer"
    ADD CONSTRAINT "Answer_idQuestion_fkey" FOREIGN KEY (id_question) REFERENCES public."Question"(id_question);


--
-- Name: Curiosity_forum_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Curiosity"
    ADD CONSTRAINT "Curiosity_forum_type_fkey" FOREIGN KEY (forum_type) REFERENCES public."Forum"(type_forum);


--
-- Name: Favorite_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_material_id_fkey" FOREIGN KEY (material_id) REFERENCES public."Material"(id);


--
-- Name: Favorite_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Favorite"
    ADD CONSTRAINT "Favorite_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id);


--
-- Name: Forum_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Forum"
    ADD CONSTRAINT "Forum_library_id_fkey" FOREIGN KEY (library_id) REFERENCES public."Library"(id_library);


--
-- Name: Library_Material_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_Material"
    ADD CONSTRAINT "Library_Material_library_id_fkey" FOREIGN KEY (library_id) REFERENCES public."Library"(id_library);


--
-- Name: Library_Material_material_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_Material"
    ADD CONSTRAINT "Library_Material_material_id_fkey" FOREIGN KEY (material_id) REFERENCES public."Material"(id);


--
-- Name: Library_User_library_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_User"
    ADD CONSTRAINT "Library_User_library_id_fkey" FOREIGN KEY (library_id) REFERENCES public."Library"(id_library);


--
-- Name: Library_User_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Library_User"
    ADD CONSTRAINT "Library_User_user_id_fkey" FOREIGN KEY (user_id) REFERENCES public."User"(id);


--
-- Name: Question_forum_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Question"
    ADD CONSTRAINT "Question_forum_type_fkey" FOREIGN KEY (forum_type) REFERENCES public."Forum"(type_forum);


--
-- Name: Share_forum_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: BiAMa
--

ALTER TABLE ONLY public."Share"
    ADD CONSTRAINT "Share_forum_type_fkey" FOREIGN KEY (forum_type) REFERENCES public."Forum"(type_forum);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

